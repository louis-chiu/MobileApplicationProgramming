package com.example.menudemo_s1080418;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    //
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //將 menu 與主程式串接
        getMenuInflater().inflate(R.menu.optionmenu, menu);
        menu.add(10, 5, 1, "MenuAddItem01");
        menu.add(10, 6, 0, "MenuAddItem02");

        return super.onCreateOptionsMenu(menu);

    }

    //


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.color:
                getWindow().getDecorView().setBackgroundColor(Color.BLUE);
                break;
            case R.id.setting:

                break;
            case R.id.calc:
                break;
            case R.id.car:
                break;
            case 5:
                TextView tv = findViewById(R.id.tv);
                tv.setText(String.valueOf(item.getItemId()));
                break;
            case 6:

                break;
        }

        return super.onOptionsItemSelected(item);
    }
}