package com.example.icp3_s1080418;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView tv;
    ImageView iv1, iv2 ;
    float sp_x,sp_y,ep_x,ep_y;
    float pic_x0,pic_x1,pic_y0,pic_y1;
    float slope;
    boolean in_state, out_state, pass_state;
    float SQR3 = (float) Math.sqrt(3);
    @SuppressLint({"MissingInflatedId", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.textView);
        iv1 = findViewById(R.id.imageView1);
        iv2 = findViewById(R.id.imageView2);
        //手勢提示
        AlertDialog.Builder cfm = new AlertDialog.Builder(MainActivity.this);
        cfm.setTitle("手勢提示")
                .setMessage("↖\n↗\n↙\n↘\n")
                .setPositiveButton("OK",null)
                .create()
                .show();

        //觸控區
        FrameLayout fl = findViewById(R.id.frameLayout);
        fl.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                int act= motionEvent.getAction();
                pic_x0 = iv2.getX();
                pic_x1 = iv2.getX() + iv2.getWidth();
                pic_y0 = iv2.getY();
                pic_y1 = iv2.getY() + iv2.getHeight();

                switch (act){
                    case MotionEvent.ACTION_DOWN:
                        sp_x = motionEvent.getX();
                        sp_y = motionEvent.getY();
                        break;
                    case MotionEvent.ACTION_UP:
                        ep_x = motionEvent.getX();
                        ep_y = motionEvent.getY();
                        slope = (ep_y - sp_y) / (ep_x - sp_x);

                        if (pass_state) {
                            if (ep_x - sp_x > 0) { // 往右 +
                                if (ep_y - sp_y > 0) { // 下 +
                                    if (Math.abs(slope) > (1f / SQR3) && Math.abs(slope) < SQR3)
                                        iv2.setImageResource(R.drawable.pic1);  //blue
                                } else if (ep_y - sp_y < 0) {  // 上 -
                                    if (Math.abs(slope) > (1f / SQR3) && Math.abs(slope) < SQR3)
                                        iv2.setImageResource(R.drawable.pic2); //green
                                }

                            } else if (ep_x - sp_x < 0) {  //往左 -
                                if (ep_y - sp_y > 0) { // 下 +
                                    if (Math.abs(slope) > (1f / SQR3) && Math.abs(slope) < SQR3)
                                        iv2.setImageResource(R.drawable.pic4); //orange

                                } else if (ep_y - sp_y < 0) {  // 上 -
                                    if (Math.abs(slope) > (1f / SQR3) && Math.abs(slope) < SQR3)
                                        iv2.setImageResource(R.drawable.pic5);  //purple

                                }
                            }
                        }
                        in_state=false;
                        pass_state=false;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        //取得座標
                        tv.setText(motionEvent.getX()+"\n"+motionEvent.getY());
                        iv1.setX(motionEvent.getX() - iv1.getWidth()/2);
                        iv1.setY(motionEvent.getY() - iv1.getHeight()/2);
                        if(motionEvent.getX() > pic_x0 && motionEvent.getX() < pic_x1 && motionEvent.getY() > pic_y0 && motionEvent.getY() < pic_y1){
                            in_state = true;
                        }else if(in_state){
                            pass_state = true;
                        }



                        //姿勢判斷

                        break;
                }
                return true;
            }
        });


    }
}