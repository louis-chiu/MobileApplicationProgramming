package com.example.icp02_s1080418;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button num_arr[] = new Button[10];
    Button opr_arr[] = new Button[4];
    Button btnEql, btnMul, btnMin, btnAdd, btnDel, btnClr;
    RadioGroup rg;
    RadioButton rbD, rbB, rbH;
    TextView tv;
    ImageView iv;
    int tol1, tol2, opr;
    int i, j;
    boolean status = false;
    boolean eql_status = false;
    int sign;
    String temp;
    boolean add, min, mul, div;
    CharSequence cur_str;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.textView);
        btnDel =findViewById(R.id.buttonDel);
        btnEql = findViewById(R.id.buttonEql);
        rbD = findViewById(R.id.radioButton1);
        rbB = findViewById(R.id.radioButton2);
        rbH = findViewById(R.id.radioButton3);
        rg = findViewById(R.id.radioGroup);
        iv = findViewById(R.id.imageView);
        //
        View.OnClickListener num_btLTR = new View.OnClickListener() {


            //number LTR
            @Override
            public void onClick(View view) {

                //tv 設置數字
                if (!status) {
                    cur_str = tv.getText();
                    tv.setText((String) cur_str + ((Button) view).getText());
                } else {
                    cur_str = "";
                    tv.setText((String) cur_str + ((Button) view).getText());
                }

                status=false;
            }
        };

        View.OnClickListener opr_btLTR = new View.OnClickListener() {
            //operator LTR
            @Override
            public void onClick(View view) {
                if(tv.getText().length()!=0)
                    tol1 = Integer.valueOf(tv.getText().toString());
                sign = view.getId();
                //Toast.makeText(MainActivity.this, sign,Toast.LENGTH_LONG).show();
                //+ - * /
                if (sign == 2131231229) {
                    opr = 1;
                } else if (sign == 2131231230) {
                    opr = 2;
                } else if (sign == 2131231231) {
                    opr = 3;
                } else if (sign == 2131231232) {
                    opr = 4;
                }
                status = true;
            }
        };

        View.OnClickListener eql_btLTR = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tv.getText().length()!=0)
                    tol2 = Integer.valueOf(tv.getText().toString());
                if(opr == 1&& !eql_status){
                    tol1 += tol2;
                    temp = String.valueOf(tol1);
                    tv.setText(temp);
                }else if (opr == 2&& !eql_status){
                    tol1 -= tol2;
                    temp = String.valueOf(tol1);
                    tv.setText(temp);
                }else if (opr == 3&& !eql_status){

                }else if (opr == 4&& !eql_status){

                }
                eql_status=true;

            }
        };

        View.OnClickListener del_btLTR = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tv.getText().length() != 0) {
                    cur_str = tv.getText();
                    cur_str = cur_str.toString().substring(0, cur_str.length() - 1);
                    tv.setText(cur_str);
                }
            }
        };

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i == rbD.getId())
                    iv.setImageResource(R.drawable.one);
                if(i == rbB.getId())
                    iv.setImageResource(R.drawable.two);
                if(i == rbH.getId())
                    iv.setImageResource(R.drawable.three);
            }
        });


        btnDel.setOnClickListener(del_btLTR);
        btnEql.setOnClickListener(eql_btLTR);
        for (i = 0; i < 10; i++){
            String btn = "button" + (i);
            int btn_id = getResources().getIdentifier(btn,"id",getPackageName());
            num_arr[i] = findViewById(btn_id);
            num_arr[i].setOnClickListener(num_btLTR);
        }
        for (j = 11; j < 15; j++){
            String btn = "button" + (j);
            int btn_id = getResources().getIdentifier(btn,"id",getPackageName());
            opr_arr[j-11] = findViewById(btn_id);
            opr_arr[j-11].setOnClickListener(opr_btLTR);
        }





    }
}